#ifndef POINT_H_
#define POINT_H_

using namespace std;

class Point
{
public:
	int x;
	int y;
	int dx;
	int dy;
	
	Point();
	~Point();
};
#endif