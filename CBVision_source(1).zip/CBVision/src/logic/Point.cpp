#include "Point.h"

Point::Point():
	x(0),
	y(0),
	dx(0),
	dy(0)
{
}

Point::~Point()
{
}